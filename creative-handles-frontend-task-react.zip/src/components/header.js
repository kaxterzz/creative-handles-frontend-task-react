import React, { useState, useEffect } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faBars } from '@fortawesome/free-solid-svg-icons'

function Header() {

    useEffect(() => {
        
    });

    toggleCls = e => {
        e.target.toggleClass = 'active'
    }

    return (
        
    );
}

export default Header