import React from 'react';
import Content from './components/content'
import './styles/k-grid.css';
import './styles/styles.scss'

function App() {
  return (
    <div className="App">
      <Content/>
    </div>
  );
}

export default App;
